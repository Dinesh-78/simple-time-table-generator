package com.time;

public class Table {
	String fir;
	String sec;
	String thi;
	String fou;
	String fiv;
	String day;
	public String getFir() {
		return fir;
	}
	public String getSec() {
		return sec;
	}
	public String getThi() {
		return thi;
	}
	public String getFou() {
		return fou;
	}
	public String getFiv() {
		return fiv;
	}
	public String getDay() {
		return day;
	}
	public void setFir(String fir) {
		this.fir = fir;
	}
	public void setSec(String sec) {
		this.sec = sec;
	}
	public void setThi(String thi) {
		this.thi = thi;
	}
	public void setFou(String fou) {
		this.fou = fou;
	}
	public void setFiv(String fiv) {
		this.fiv = fiv;
	}
	public void setDay(String day) {
		this.day= day;
	}

}
